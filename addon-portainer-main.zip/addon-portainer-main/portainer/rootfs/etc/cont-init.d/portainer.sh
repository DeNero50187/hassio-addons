#!/usr/bin/with-contenv bashio
# ==============================================================================
# Home Assistant Community Add-on: Portainer
# Runs some initializations for Portainer
# ==============================================================================
bashio::require.unprotected
